extends CharacterBody2D

# --- UI Sprite References ---
# (Make sure to right-click both nodes in your Scene Tree and check "Access as Unique Name")
@onready var fuel_sprite: AnimatedSprite2D = %FuelSprite2D
@onready var health_sprite: AnimatedSprite2D = %HealthSprite2D

# --- Movement Settings ---
@export_category("Movement Settings")
@export var speed: float = 50.0
@export var steering_speed: float = 5.0

# --- Drift Settings ---
@export_category("Drift Settings")
@export var normal_traction: float = 0.1
@export var drift_traction: float = 0.02

# --- Health Settings ---
@export_category("Health Settings")
@export var max_health: float = 100.0
@export var crash_damage_per_sec: float = 10.0  # Drains 10 HP/sec hitting walls
@export var police_damage_per_sec: float = 40.0 # Drains 40 HP/sec touching police

# --- Fuel Settings ---
@export_category("Fuel Settings")
@export var max_fuel: float = 100.0
@export var fuel_consumption_rate: float = 3.0  # Drains 3 fuel/sec while moving

# --- Internal Variables ---
var current_traction: float = 0.0
var health: float = 100.0
var fuel: float = 100.0

func _ready() -> void:
	health = max_health
	fuel = max_fuel
	
	# Stop default animations if they are set to autoplay so frame control works manually
	if fuel_sprite:
		fuel_sprite.stop()
	if health_sprite:
		health_sprite.stop()
		
	update_fuel_sprite()
	update_health_sprite()

func _physics_process(delta: float) -> void:
	# Steering
	var steer_direction = Input.get_axis("ui_left", "ui_right")
	rotation += steer_direction * steering_speed * delta

	# Direction & Traction
	var target_velocity = Vector2.ZERO
	
	# Only allow movement/steering if you have fuel
	if fuel > 0:
		target_velocity = Vector2.RIGHT.rotated(rotation) * speed
		consume_fuel(delta)

	current_traction = normal_traction
	if Input.is_action_pressed("ui_accept"): 
		current_traction = drift_traction

	velocity = velocity.lerp(target_velocity, current_traction)

	# Move car
	move_and_slide()
	
	# Check for continuous collisions
	handle_collisions(delta)

func consume_fuel(delta: float) -> void:
	fuel -= fuel_consumption_rate * delta
	fuel = max(fuel, 0.0)
	update_fuel_sprite()

func refuel(amount: float) -> void:
	fuel += amount
	fuel = min(fuel, max_fuel)
	update_fuel_sprite()

func take_damage(amount: float) -> void:
	health -= amount
	health = max(health, 0.0)
	update_health_sprite()

# --- Sprite Frame Updates ---
func update_fuel_sprite() -> void:
	if fuel_sprite:
		var clamped_fuel = clamp(fuel, 0.0, max_fuel)
		# Remaps fuel (100 -> 0) to frame index (0 -> 49)
		fuel_sprite.frame = int(remap(clamped_fuel, max_fuel, 0.0, 0.0, 49.0))

func update_health_sprite() -> void:
	if health_sprite:
		var clamped_health = clamp(health, 0.0, max_health)
		# Remaps health (100 -> 0) to frame index (0 -> 39)
		health_sprite.frame = int(remap(clamped_health, max_health, 0.0, 0.0, 39.0))

func handle_collisions(delta: float) -> void:
	# Continuous check while colliding
	for i in get_slide_collision_count():
		var collision = get_slide_collision(i)
		var collider = collision.get_collider()

		if collider:
			# If touching Police, drain health fast
			if collider.is_in_group("Police"):
				take_damage(police_damage_per_sec * delta)
				break
			# If touching regular wall/obstacle, drain slower
			else:
				take_damage(crash_damage_per_sec * delta)
				break

	# Game Over condition check
	var game_manager = get_parent().get_node_or_null("GameManager")
	if health <= 0 or fuel <= 0:
		if game_manager:
			game_manager.trigger_game_over()
