extends Control

@export var final_score_label: Label

func _ready() -> void:
	# Grab the score saved by the GameManager right before the crash
	if final_score_label:
		final_score_label.text = "Final Score: " + str(GlobalStats.final_score)

# Connect this function to your RestartButton's "pressed()" signal in the Node tab
func _on_restart_button_pressed() -> void:
	# Load back into your city gameplay loop
	# Change "res://CityScene.tscn" to match your actual gameplay scene file path!
	get_tree().change_scene_to_file("res://CityScene.tscn")
