extends Node

@export var score_label: Label
@export var health_label: Label

@export var score_per_second: float = 15.0
var current_score: float = 0.0
var is_game_over: bool = false

func _ready() -> void:
	if health_label:
		health_label.text = "Engine: 100%"

func _process(delta: float) -> void:
	if not is_game_over:
		current_score += score_per_second * delta
		if score_label:
			score_label.text = "Score: " + str(int(current_score))

func update_health_ui(current_health: float) -> void:
	if health_label:
		health_label.text = "Engine: " + str(int(current_health)) + "%"

func trigger_game_over() -> void:
	if is_game_over: return
	is_game_over = true
	
	# 1. Store the final score in our persistent Autoload node
	GlobalStats.final_score = int(current_score)
	
	# 2. Change the scene to your separate game over scene
	# Change "res://GameOverScene.tscn" to match your actual game over file path!
	get_tree().change_scene_to_file("res://GameOverScene.tscn")
