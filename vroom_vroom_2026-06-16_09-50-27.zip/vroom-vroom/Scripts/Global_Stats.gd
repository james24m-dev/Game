extends Node

# This variable will survive the scene swap
var final_score: int = 0
