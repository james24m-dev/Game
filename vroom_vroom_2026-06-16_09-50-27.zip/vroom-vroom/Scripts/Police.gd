extends CharacterBody2D

@export_category("Movement Settings")
@export var speed: float = 350.0          # Top speed of the police car
@export var steering_speed: float = 2.5   # How fast the police car can turn

@export_category("Drift Settings")
# Traction controls how much the tires grip the road (0.0 = ice, 1.0 = instant grip)
# A lower value means the police car will slide more through turns
@export var police_traction: float = 0.04 

# We need a reference to the player car to know where to drive
var player: CharacterBody2D = null

func _ready() -> void:
	# Look through the active scene to find the player car node
	player = get_parent().get_node_or_null("Car")

func _physics_process(delta: float) -> void:
	# If the player doesn't exist, stop moving
	if not player:
		velocity = velocity.lerp(Vector2.ZERO, police_traction)
		move_and_slide()
		return

	# 1. Calculate the direction vector toward the player
	var direction_to_player = (player.global_position - global_position).normalized()

	# 2. Find the angle we need to turn to face the player
	var target_angle = direction_to_player.angle()

	# 3. Smoothly rotate the police car toward that target angle
	rotation = rotate_toward(rotation, target_angle, steering_speed * delta)

	# 4. Find the ideal velocity the police car *wants* to go
	var target_velocity = Vector2.RIGHT.rotated(rotation) * speed

	# 5. Blend the current velocity toward the target velocity to create the slide
	velocity = velocity.lerp(target_velocity, police_traction)

	# 6. Move and handle collisions
	move_and_slide()
