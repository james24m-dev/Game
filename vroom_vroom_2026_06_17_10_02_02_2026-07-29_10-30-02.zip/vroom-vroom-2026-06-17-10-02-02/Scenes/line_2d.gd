extends Line2D

var previous_position: Vector2 = Vector2.ZERO

func _ready():
	top_level = true
	global_position = Vector2.ZERO
	previous_position = get_parent().global_position

func _physics_process(delta):
	var current_position = get_parent().global_position
	
	add_point(current_position)
		
	if points.size() > 80:
		remove_point(0)
		
	previous_position = current_position
