extends Area2D

@export var refuel_amount: float = 100.0

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player") and body.has_method("refuel"):
		body.refuel(refuel_amount)
