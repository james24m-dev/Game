extends Node

@export_category("Player Reference")
@export var player_node_name: String = "Car"   # Name of your player car node in the scene

@export_category("Idle Settings")
@export var max_idle_time: float = 5.0          # Seconds allowed to stand still
@export var minimum_speed_threshold: float = 5.0 # Speed below which player counts as "stopped"

var idle_timer: float = 0.0
var player: CharacterBody2D = null

func _ready() -> void:
	# Find player car in the same scene
	player = get_parent().get_node_or_null(player_node_name) as CharacterBody2D
	
	if not player:
		push_error("IdleLossManager: Could not find player node named '" + player_node_name + "'")

func _physics_process(delta: float) -> void:
	if not is_instance_valid(player):
		return

	# Measure player physical speed
	var current_speed = player.velocity.length()

	if current_speed < minimum_speed_threshold:
		idle_timer += delta
		
		if idle_timer >= max_idle_time:
			trigger_idle_game_over()
	else:
		# Reset timer when player moves
		idle_timer = 0.0

func trigger_idle_game_over() -> void:
	set_physics_process(false)
	
	print("Lost! Player was idle for too long.")
	
	var game_manager = get_parent().get_node_or_null("GameManager")
	if game_manager and game_manager.has_method("trigger_game_over"):
		game_manager.trigger_game_over()
