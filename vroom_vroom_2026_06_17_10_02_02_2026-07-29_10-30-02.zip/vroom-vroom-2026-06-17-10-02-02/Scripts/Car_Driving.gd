extends CharacterBody2D

@export_category("Movement Settings")
@export var speed = 50.0
@export var steering_speed = 5.0

@export_category("Drift Settings")
@export var normal_traction = 0.1
@export var drift_traction = 0.02 

@export_category("Health Settings")
@export var max_health: float = 100.0
@export var crash_damage_per_sec: float = 10.0  # Drains 10 HP/sec hitting walls
@export var police_damage_per_sec: float = 40.0 # Drains 40 HP/sec touching police

@export_category("Fuel Settings")
@export var max_fuel: float = 100.0
@export var fuel_consumption_rate: float = 3.0  # Drains 5 fuel/sec while moving

var current_traction = 0.0
var health: float = 100.0
var fuel: float = 100.0

func _ready() -> void:
	health = max_health
	fuel = max_fuel

func _physics_process(delta: float) -> void:
	# Steering
	var steer_direction = Input.get_axis("ui_left", "ui_right")
	rotation += steer_direction * steering_speed * delta

	# Direction & Traction
	var target_velocity = Vector2.ZERO
	
	# Only allow movement/steering if you have fuel
	if fuel > 0:
		target_velocity = Vector2.RIGHT.rotated(rotation) * speed
		consume_fuel(delta)

	current_traction = normal_traction
	if Input.is_action_pressed("ui_accept"): 
		current_traction = drift_traction

	velocity = velocity.lerp(target_velocity, current_traction)

	# Move car
	move_and_slide()
	
	# Pass 'delta' so damage drains continuously over time
	handle_collisions(delta)

func consume_fuel(delta: float) -> void:
	fuel -= fuel_consumption_rate * delta
	fuel = max(fuel, 0.0)

func refuel(amount: float) -> void:
	fuel += amount
	fuel = min(fuel, max_fuel)

func handle_collisions(delta: float) -> void:
	# Continuous check while colliding
	for i in get_slide_collision_count():
		var collision = get_slide_collision(i)
		var collider = collision.get_collider()

		if collider:
			# If touching Police, drain health fast
			if collider.is_in_group("Police"):
				take_damage(police_damage_per_sec * delta)
				break
			# If touching regular wall/obstacle, drain slower
			else:
				take_damage(crash_damage_per_sec * delta)
				break

	# Health & Fuel UI Updates
	var game_manager = get_parent().get_node_or_null("GameManager")
	if game_manager:
		game_manager.update_health_ui(health)
		if game_manager.has_method("update_fuel_ui"):
			game_manager.update_fuel_ui(fuel)
	
	if health <= 0 or fuel <= 0:
		if game_manager:
			game_manager.trigger_game_over()

func take_damage(amount: float) -> void:
	health -= amount
