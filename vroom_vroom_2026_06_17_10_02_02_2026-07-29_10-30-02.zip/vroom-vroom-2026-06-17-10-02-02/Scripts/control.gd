extends Control

@export var final_score_label: Label

func _ready() -> void:
	if final_score_label:
		final_score_label.text = "Final Score: " + str(GlobalStats.final_score)

func _on_restart_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")
