extends Node

@export var score_label: Label
@export var health_label: Label
@export var fuel_label: Label # Added Fuel Label reference

@export var score_per_second: float = 15.0
var current_score: float = 0.0
var is_game_over: bool = false

func _ready() -> void:
	if health_label:
		health_label.text = "Engine: 100%"
	if fuel_label:
		fuel_label.text = "Fuel: 100%"

func _process(delta: float) -> void:
	if not is_game_over:
		current_score += score_per_second * delta
		if score_label:
			score_label.text = "Score: " + str(int(current_score))	

func update_health_ui(current_health: float) -> void:
	if health_label:
		health_label.text = "Engine: " + str(int(current_health)) + "%"

func update_fuel_ui(current_fuel: float) -> void:
	if fuel_label:
		fuel_label.text = "Fuel: " + str(int(current_fuel)) + "%"



func trigger_game_over() -> void:
	if is_game_over: return
	is_game_over = true
	
	GlobalStats.final_score = int(current_score)
	
	get_tree().change_scene_to_file("res://Scenes/game_over.tscn")
