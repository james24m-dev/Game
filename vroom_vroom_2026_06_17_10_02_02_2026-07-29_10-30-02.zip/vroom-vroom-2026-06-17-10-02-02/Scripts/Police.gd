extends CharacterBody2D

@export_category("Movement Settings")
@export var speed: float = 80.0          # Top speed of the police car
@export var steering_speed: float = 2.5   # How fast the police car can turn

@export_category("Damage Settings")
@export var damage_per_second: float = 40.0 # Drains 40 HP per second while contacting player

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D
@onready var detection_zone: Area2D = $DetectionZone

var player: Node2D = null

func _ready() -> void:
	# Find the player node in the scene
	player = get_parent().get_node_or_null("Car")
	await get_tree().physics_frame
	
	nav_agent.path_desired_distance = 80.0
	nav_agent.target_desired_distance = 20.0

func _physics_process(delta: float) -> void:
	# Stop processing if player doesn't exist
	if not is_instance_valid(player):
		return

	# --- 1. NAVIGATION & MOVEMENT ---
	nav_agent.target_position = player.global_position
	var next_path_position: Vector2 = nav_agent.get_next_path_position()

	var direction_to_next_point = (next_path_position - global_position).normalized()
	var target_angle = direction_to_next_point.angle()

	# Rotate nose toward navigation path
	rotation = rotate_toward(rotation, target_angle, steering_speed * delta)

	# Set velocity and move
	var target_direction = Vector2.RIGHT.rotated(rotation)
	velocity = target_direction * speed
	move_and_slide()

	# --- 2. CONTINUOUS DAMAGE DRAIN ---
	# Check every body currently touching or inside the Area2D shape
	for body in detection_zone.get_overlapping_bodies():
		if body.has_method("take_damage") and body != self:
			body.take_damage(damage_per_second * delta)
