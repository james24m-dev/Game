extends Node

@export var score_label: Label
@export var health_label: Label

@export var score_per_second: float = 15.0
var current_score: float = 0.0
var is_game_over: bool = false

func _ready() -> void:
	if health_label:
		health_label.text = "Engine: 100%"

func _process(delta: float) -> void:
	if not is_game_over:
		current_score += score_per_second * delta
		if score_label:
			# FIX: Removed the extra '"score_label"' string inside the int() function
			score_label.text = "Score: " + str(int(current_score))

func update_health_ui(current_health: float) -> void:
	if health_label:
		health_label.text = "Engine: " + str(int(current_health)) + "%"

func trigger_game_over() -> void:
	if is_game_over: return
	is_game_over = true
	
	# FIX: Save the score to your global stats variable
	GlobalStats.final_score = int(current_score)
	
	# FIX: Removed the broken UI text assignment here since final_score_label 
	# belongs to the next scene, not this script.
	
	# Switch to the game over scene
	get_tree().change_scene_to_file("res://Scenes/game_over.tscn")
