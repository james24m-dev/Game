extends CharacterBody2D

@export_category("Movement Settings")
@export var speed = 50.0
@export var steering_speed = 5.0

@export_category("Drift Settings")
@export var normal_traction = 0.1
@export var drift_traction = 0.02 

@export_category("Health Settings")
@export var max_health: float = 100.0
@export var crash_damage: float = 1.0  
@export var police_damage: float = 20.0      

var current_traction = 0.0
var health: float = 100.0



func _ready() -> void:
	health = max_health

func _physics_process(delta: float) -> void:
	#steering
	var steer_direction = Input.get_axis("ui_left", "ui_right")
	rotation += steer_direction * steering_speed * delta

	#find the direction the car is facing
	var target_velocity = Vector2.RIGHT.rotated(rotation) * speed

	#decide how much grip the tires have
	current_traction = normal_traction
	if Input.is_action_pressed("ui_accept"): 
		current_traction = drift_traction

	#blend the current velocity toward the target velocity
	velocity = velocity.lerp(target_velocity, current_traction)

	#move the car
	move_and_slide()
	
	#check for collisions
	handle_collisions()

func handle_collisions() -> void:
	for i in get_slide_collision_count():
		var collision = get_slide_collision(i)
		take_damage(crash_damage)
		print('Hit')
	
	#health manager
	var game_manager = get_parent().get_node_or_null("GameManager")
	if game_manager:
		game_manager.update_health_ui(health)
	
	if health <= 0:
		health = 0
		if game_manager:
			game_manager.trigger_game_over()
			

func take_damage(amount: float) -> void:
	health -= amount
