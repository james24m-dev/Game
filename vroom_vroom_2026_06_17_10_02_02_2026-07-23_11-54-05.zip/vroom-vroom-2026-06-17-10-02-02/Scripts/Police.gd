extends CharacterBody2D

@export_category("Movement Settings")
@export var speed: float = 80.0          # Top speed of the police car
@export var steering_speed: float = 2.5   # How fast the police car can turn

@export_category("Drift Settings")
@export var police_traction: float = 0.04 

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D
var player: CharacterBody2D = null

func _ready() -> void:
	# Find the player node in the scene
	player = get_parent().get_node_or_null("Car")
	await get_tree().physics_frame
	
	nav_agent.path_desired_distance = 80.0
	nav_agent.target_desired_distance = 20.0

func _physics_process(delta: float) -> void:
	# Update the agent's target position to where the player currently is
	nav_agent.target_position = player.global_position

	#get the next position along the TileMap road path
	var next_path_position: Vector2 = nav_agent.get_next_path_position()

	#calculate the direction vector toward that road path point
	var direction_to_next_point = (next_path_position - global_position).normalized()

	#find the angle needed to turn toward the path
	var target_angle = direction_to_next_point.angle()

	#rotate the police car's nose toward that target angle
	rotation = rotate_toward(rotation, target_angle, steering_speed * delta)

	var target_direction = Vector2.RIGHT.rotated(rotation)
	velocity = target_direction * speed

	#move the car and handle wall collisions
	move_and_slide()
