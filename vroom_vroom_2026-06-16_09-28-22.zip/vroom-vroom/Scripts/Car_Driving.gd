extends CharacterBody2D

@export var speed = 650.0
@export var steering_speed = 2.8

# Traction values (0.0 means no grip, 1.0 means instant grip)
@export var normal_traction = 0.1
@export var drift_traction = 0.01

func _physics_process(delta: float) -> void:
	# 1. Handle Steering
	var steer_direction = Input.get_axis("ui_left", "ui_right")
	rotation += steer_direction * steering_speed * delta

	# 2. Find the direction the car is facing
	var target_velocity = Vector2.RIGHT.rotated(rotation) * speed

	# 3. Decide how much grip the tires have
	var current_traction = normal_traction
	if Input.is_action_pressed("ui_accept"): # Spacebar by default
		current_traction = drift_traction

	# 4. Blend the current velocity toward the target velocity
	# This creates the slide!
	velocity = velocity.lerp(target_velocity, current_traction)

	# 5. Move the car
	move_and_slide()
