extends Node

# Drag your ScoreLabel from the scene tree into this slot in the Inspector
@export var score_label: Label

# Scoring variables
@export var score_per_second: float = 15.0
var current_score: float = 0.0
var is_game_over: bool = false

func _process(delta: float) -> void:
	# If the player hasn't died yet, accumulate points
	if not is_game_over:
		# delta ensures we add score based on actual time passed, not frame rate
		current_score += score_per_second * delta
		
		# Update the display (int() cuts off the decimal points)
		if score_label:
			score_label.text = "Score: " + str(int(current_score))
